# Shopee

## Instalar dependências
```
> composer install --ignore-platform-reqs
```

## Iniciar projeto

```
> php spark serve
```