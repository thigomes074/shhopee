<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

$routes->get('/','PageController::ShowOperationSelector');

//Users
$routes->get('/users','UsersController::index');

$routes->get('/users/create','UsersController::showStore');
$routes->post('/users/create','UsersController::store');

$routes->get('/users/edit/(:num)','UsersController::showUpdate/$1');
$routes->post('/users/edit/(:num)','UsersController::update/$1');

$routes->get('/users/delete/(:num)','UsersController::delete/$1');

//Categories
$routes->get('/categories','CategoriesController::index');

$routes->get('/categories/create','CategoriesController::showStore');
$routes->post('/categories/create','CategoriesController::store');

$routes->get('/categories/edit/(:num)','CategoriesController::showUpdate/$1');
$routes->post('/categories/edit/(:num)','CategoriesController::update/$1');

$routes->get('/categories/delete/(:num)','CategoriesController::delete/$1');

//Products
$routes->get('/products','ProductsController::index');

$routes->get('/products/create','ProductsController::showStore');
$routes->post('/products/create','ProductsController::store');

$routes->get('/products/edit/(:num)','ProductsController::showUpdate/$1');
$routes->post('/products/edit/(:num)','ProductsController::update/$1');

$routes->get('/products/delete/(:num)','ProductsController::delete/$1');

//Orders
$routes->get('/orders','OrdersController::getAllOrders');
$routes->get('/orders/(:num)','OrdersController::getOrders/$1');
$routes->get('/orders/edit/(:num)','OrdersController::ShowEditOrderForm/$1');
$routes->post('/orders/edit/(:num)','OrdersController::editOrder/$1');
$routes->get('/orders/delete/(:num)','OrdersController::deleteOrder/$1');
$routes->get('/orders/create','OrdersController::showCreateOrderForm');
$routes->post('/orders/create','OrdersController::createOrder');
$routes->get('/orders/pay/(:num)','OrdersController::payOrder/$1');





/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
