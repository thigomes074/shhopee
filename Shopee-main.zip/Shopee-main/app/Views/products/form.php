<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopee</title>
</head>
<body>
    <header>
        <h1>Shopee</h1>
        <nav>
            <ul>
                <li><a href="/users/">Usuários</a></li>
                <li><a href="/products/">Produtos</a></li>
                <li><a href="/categories/">Categorias</a></li>
                <li><a href="/orders/">Pedidos</a></li>
            </ul>
        </nav>
    </header>
    <main>

        <form method="post">
            <h2><?php echo ($name!='') ? "Edite um produto" : "Adicione um produto";?></h2>
            <input type="text" placeholder="Insira um nome" name=name value="<?php echo $name!='' ? $name : ''; ?>">
            <input type="text" placeholder="Insira uma sinopse" name="sinopse" value="<?php echo $name!='' ? $sinopse : ''; ?>">
            <input type="number" min=0 placeholder="Insira uma quantidade" name="qt" value="<?php echo $name!='' ? $qt : ''; ?>">
            <input type="number" min=0.0 placeholder="price" name="price" value="<?php echo $name!='' ? $price : ''; ?>">
            
            <select id=select_category>
                <option value=0 selected>Selecione uma categoria</option>
                <?php
                    foreach($categories as $category){
                        echo "<option value=$category[id]>$category[name]</option>";
                    }
                ?>
            </select>
            <?php
                echo "<div id=add_selects>";
                    $categories=[];
                    foreach($product_categories as $pc){
                        echo "<div id=\"categories$pc[id]\" style=\"display:flex;justify-content:center;\">";
                            echo "<div>";
                                echo $pc["name"];
                            echo "</div>";
                            echo "<div style=\"display:none\">";
                                echo $pc["id"];
                                array_push($categories,$pc['id']);
                            echo "</div>";
                            echo "<button type=\"button\">X</button>";
                        echo "</div>";
                    }
                echo "</div>";
                $categories=implode(',',$categories);
                echo "<input id=send_categories type=hidden name=categories value=$categories>";   
            ?>
            <input type="submit" value="<?php echo $name!='' ? "Salvar" : "Registrar"; ?>" >
        </form>
    </main>
    <script>
        let cached_options=[];
        const select=document.getElementById("select_category");
        const div=document.getElementById("add_selects");
        const send_categories=document.getElementById("send_categories");
        function removeNodeFromDiv_addselect(id){
            node=document.getElementById(`categories${id}`)
            const option_value=node.children[1].innerText;
            const option_TXT=node.children[0].innerText;
            const options=document.createElement("option");
                  options.value=option_value;
                  options.innerHTML=option_TXT;
            
            const tmp_array=send_categories.value.split(',')
            
            const index=tmp_array.findIndex(categoryId => categoryId=id);
            if(index!=-1) tmp_array.splice(index,1);
            send_categories.value=tmp_array.join(',');
            select.append(options);            
            node.remove();
        }
        window.onload=()=>{
            for(let child of div.children){
                const remove_button=child.children[2];
                const div_category_id=child.children[1];
                cached_options.push(parseInt(div_category_id.innerHTML));
                remove_button.onclick=()=>{removeNodeFromDiv_addselect(parseInt(div_category_id.innerHTML))};
            }
            cached_options.forEach(id=>{
                arrayOptions=Array.prototype.slice.call(select.options);
                OptionIndex=arrayOptions.findIndex(option=>option.value==id);
                select.remove(OptionIndex);
            });
        };

        select.onchange=()=>{
            const selectedIndex=select.options.selectedIndex;
            const selectedValue=select.options[selectedIndex].value;
            const selectedInnerHTML=select.options[selectedIndex].innerHTML;


            const tmp_array=send_categories.value.length>0 ? send_categories.value.split(','):[];
            tmp_array.push(selectedValue);
            send_categories.value=tmp_array.join(',');

            div_category=document.createElement("div");
                div_category.classList.add("category");
                div_category.style="display:flex;justify-content:center";
                div_category.id=`categories${selectedValue}`;
            div_category_name=document.createElement("div");
                div_category_name.classList.add("category_name");
                div_category_name.innerText=selectedInnerHTML;
            div_category_id=document.createElement("div");
                div_category_id.classList.add("category_id");
                div_category_id.innerText=selectedValue;
                div_category_id.style="display:none"

            div_category_remove_button=document.createElement("button");
                div_category_remove_button.classList.add("remove_button");
                div_category_remove_button.type="button";
                div_category_remove_button.innerText="X";
                div_category_remove_button.onclick=()=>{removeNodeFromDiv_addselect(parseInt(selectedValue))};
            div_category.appendChild(div_category_name);
            div_category.appendChild(div_category_id);
            div_category.appendChild(div_category_remove_button);
            div.appendChild(div_category);
            select.remove(selectedIndex);            
            
            
        }
    </script>
</body>
</html>