<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shope</title>
</head>
<body>
    <header>
        <h1>Shopee</h1>
        <nav>
            <ul>
                <li><a href="/users/">Usuários</a></li>
                <li><a href="/products/">Produtos</a></li>
                <li><a href="/categories/">Categorias</a></li>
                <li><a href="/orders/">Pedidos</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <a href="/orders/create">Adicionar pedido</a>
        <?php
            echo "<table>";
                echo "<thead>";
                    echo "<tr>";
                        echo "<td>user</td>";
                        echo "<td>pago</td>";
                        echo "<td>products</td>";
                        echo "<td>total</td>";
                        echo "<td></td>";
                        echo "<td></td>";
                        echo "<td></td>";
                    echo  "</tr>";
                echo "</thead>";
                echo "<tbody>";
                    foreach($orders as $order){
                        $products=count($order["products"])>0 ? "":"Sem Produtos";
                        $total_product=0;
                        foreach($order["products"] as $produto){
                            $products.="$produto[name]($produto[qt] Uni),";
                            $price=$produto['price']; 
                            $qt=$produto['qt']; 
                            $total_product+=($price*$qt); 
                        }
                        echo "<tr>";
                            echo "<td>".$order['user']['email'].'</td>';
                            echo "<td>".($order['pago']==0 ? "N":"S").'</td>';
                            echo "<td>".$products.'</td>';
                            echo "<td>R$".$total_product.'</td>';
                            
                            if($order['pago']==0){
                                echo "<td><a href='/orders/edit/$order[id]'>Editar</a></td>";
                                echo "<td><a href='/orders/delete/$order[id]'>Remover</a></td>";
                                echo "<td><a href='/orders/pay/$order[id]'>Pagar</a></td>";
                            }
                        echo "</tr>";
                    }
                echo "</tbody>";
            echo "</table>";
        ?>
        <div>
            <?php
                if($total){
                    $pagesCount=ceil($total/10);
                    for($c=1;$c<=$pagesCount;$c++){
                        $calc=($c-1)*5;
                        echo "<a href=\'?offset=$calc\'>";
                            echo "$c";
                        echo "</a>";
                    }
                }
            ?> 
        </div>
    </main>
</body>
</html>
