<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopee</title>
</head>
<body>
    <header>
        <h1>Shopee</h1>
        <nav>
            <ul>
                <li><a href="/users/">Usuários</a></li>
                <li><a href="/products/">Produtos</a></li>
                <li><a href="/categories/">Categorias</a></li>
                <li><a href="/orders/">Pedidos</a></li>
            </ul>
        </nav>
    </header>
    <main>

        <form method="post" id="form">
            <h2><?php echo ($id!='') ? "Edit Order":"Register Order";?></h2>
            <?php
                echo "User<select id=select_users name=user>";
                    echo "<option value=0 selected>User</option>";
                    foreach($users as $user){
                        echo ($id_user!=$user['id'])? "<option value=$user[id]>$user[name]</option>":"<option value=$user[id] selected>$user[name]</option>";                            
                    }    
                echo "</select>";
                echo "Produtos<select id=select_products>";
                    echo "<option value=0 selected>Produtos</option>";
                    foreach($products as $product){
                        echo "<option value=$product[id] data-product-qt=$product[qt]>$product[name]</option>";
                    }    
                echo "</select>";
                echo "<h5 style=\"color:black;\">Ordered Products</h5>";
                echo "<table id=add_selects>";
                    echo "<tbody>";
                            echo "<tr>";
                                echo "<td>"."Product name"."</td>";
                                echo "<td>"."quantidade"."</td>";
                            echo "</tr>";
                        foreach($items as $item){
                            echo "<tr>";
                                echo "<td style=\"display:none;\">".$item["id_product"]."</td>";
                                echo "<td>".$item["name"]."</td>";
                                echo "<td data-product-qt=$item[productQt]>".$item["qt"]."</td>";
                                echo "<td><button type=\"button\">+</button></td>";
                                echo "<td><button type=\"button\">-</button></td>";
                            echo "</tr>";
                        }
                    echo "</tbody>";
            
                echo "</table>";

                echo "<input type=hidden  id=products_orders name=products_orders value=\"\" >";
                echo "<input type=hidden  name=created_at value=\"$created_at\">";
                echo "<input type=hidden  name=updated_at value=\"$updated_at\">";
                echo "<input id=submit_button type=button value=Enviar>";
            ?>
        </form>
    </main>
    <script>
        let cached_options=[];
        const select=document.getElementById('select_products');
        const div=document.getElementById('add_selects').children[0];
        const form=document.getElementById('form');
        const products_orders=document.getElementById('products_orders');
        const submit_button=document.getElementById("submit_button");
              submit_button.onclick=()=>submit();
        function addQtProduct(node){
            let children=node.children;
            let maxQtProduct=children[2].dataset.productQt;
            let tdQtProduct=parseInt(children[2].innerText);
            if(tdQtProduct<maxQtProduct){
                tdQtProduct++;
                children[2].innerText=tdQtProduct;
            }                     
        };
        function rmQtProduct(node){
            let children=node.children;
            let tdQtProduct=parseInt(children[2].innerText);
            if(tdQtProduct>=1){
                tdQtProduct--;
                children[2].innerText=tdQtProduct;
                if(tdQtProduct==0) rm(node)
            } 
        };
        function rm(node){
            let children=node.children;
            let option=document.createElement("option");
                option.innerText=children[1].innerText;
                option.value=children[0].innerText;
                option.dataset.productQt=children[2].dataset.productQt;
            select.append(option);
            node.remove();
        }
        function submit(){                
            products=Array.prototype.slice.call(div.children);
            products.splice(0,1);
            let JSON_Products={
                products:[]
            };
            for(let product of products){
                const productId=product.children[0].innerText;
                const productQt=product.children[2].innerText;
                const productQtDefault=product.children[2].dataset.productQt;
                const obj={
                    default_qt:productQtDefault,
                    id_product:productId,
                    qt:productQt
                }
                JSON_Products.products.push(obj);
            }
            products_orders.value=JSON.stringify(JSON_Products);
            form.submit();
        }
        window.onload=()=>{
            let trs=Array.prototype.slice.call(div.children);
            trs.splice(0,1);
            for(let tr of trs){
                cached_options.push(tr.children[0].innerText);
                tr.children[3].onclick=()=>addQtProduct(tr);
                tr.children[4].onclick=()=>rmQtProduct(tr);
            }
            cached_options.forEach(id=>{
                arrayOptions=Array.prototype.slice.call(select.options);
                OptionIndex=arrayOptions.findIndex(option=>option.value==id);
                select.remove(OptionIndex);
            });
        };
        select.onchange=()=>{
                const selectedIndex=select.options.selectedIndex;
                const selectedValue=select.options[selectedIndex].value;
                const selectedInnerHTML=select.options[selectedIndex].innerHTML;
                const tr=document.createElement("tr");
                let td=document.createElement("td");//id
                
                td.innerText=selectedValue;
                td.style="display:none;"
                tr.append(td);

                td=document.createElement("td");//name
                td.innerText=selectedInnerHTML;
                tr.append(td);
                
                td=document.createElement("td");//qt
                td.innerText=1;
                td.dataset.productQt=select.options[selectedIndex].dataset.productQt;
                tr.append(td);


                td=document.createElement("td");//+ button
                button=document.createElement("button");
                button.type="button";
                button.innerText="+";
                button.onclick=()=>addQtProduct(tr);
                td.append(button);
                tr.append(td);

                td=document.createElement("td");//- button
                button=document.createElement("button");
                button.type="button";
                button.innerText="-";
                button.onclick=()=>rmQtProduct(tr);
                td.append(button);
                tr.append(td);


                div.append(tr);
                select.remove(selectedIndex);            
        }
    </script>
</body>
</html>