<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopee</title>
</head>
<body>
    <header>
        <h1>Shopee</h1>
        <nav>
            <ul>
                <li><a href="/users/">Usuários</a></li>
                <li><a href="/products/">Produtos</a></li>
                <li><a href="/categories/">Categorias</a></li>
                <li><a href="/orders/">Pedidos</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form action="" method="get">
            <input type="text" name="search" placeholder="Procure um usuário">
            <input type="submit" value="Procurar">
        </form>
        <a href="/users/create">Adicionar usuário</a>
        <?php
            echo "<table>";
                echo "<thead>";
                    echo "<tr>";
                        echo "<th>Nome</th>";
                        echo "<th>Email</th>";
                        echo "<th></th>";
                        echo "<th></th>";
                    echo  "</tr>";
                echo "</thead>";
                echo "<tbody>";
                    foreach($users as $user){
                        echo "<tr>";
                            echo "<td>".$user['name'].'</td>';
                            echo "<td>".$user['email'].'</td>';
                            echo "<td><a href='/users/edit/$user[id]'>Editar</a></td>";
                            echo "<td><a href='/users/delete/$user[id]'>Remover</a></td>";
                        echo "</tr>";
                    }
                    if (count($users) == 0) {
                        echo "<tr>";
                            echo "<td colspan='4'>Nenhum resultado encontrado</td>";
                        echo "</tr>";
                    }
                echo "</tbody>";
            echo "</table>";
        ?>
        <div>
            <?php
                if($total){
                    $pagesCount=ceil($total/10);
                    for($c=1;$c<=$pagesCount;$c++){
                        $calc=($c-1)*5;
                        echo "<a href=\'?offset=$calc\'>";
                            echo "$c";
                        echo "</a>";
                    }
                }
            ?>
        </div>
    </main>
</body>
</html>
