<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoriesModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'categories';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function all($search='',$offset=0){
        $categories = $this->like('categories.name',$search)->findAll(10,$offset);

        return $categories;
    }

    public function create($data){
        $category = $this->insert(['name'=>$data['name']]);
        
        if($category) {
            return true;
        } else {
            return false;
        }
    }

    public function findD($id){
        return $this->find($id);
    }
    
    public function updateE($id,$data){
        $category = $this->update($id,['name'=>$data['name']]);
        
        if($category) {
            return true;
        } else {
            return false;
        }
    }

    public function deleteE($id) {
        $category = $this->delete($id);

        if($category) {
            return true;
        } else {
            return false;
        }
    }

    public function links($search = '') {
        $total = $this->like('categories.name',$search)->countAllResults();

        return $total;
    }

    public function getAllCategoriesFromProduct($productId=null){
        $this->join("Products_categories","Products_categories.id_category = Categories.id");
        $this->join("Products","Products_categories.id_product=Products.id");
        $this->select("Categories.name,Categories.id");
        $this->where("Products.id",$productId);
        return $this->findAll();
    }

    public function getAllCategoriesWithOutLimit(){
        return $this->findAll();
    }
}
