<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductsCategoriesModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'Products_categories';
    //protected $primaryKey       = 'id';
    //protected $useAutoIncrement = true;
    //protected $insertID         = 0;
    //protected $returnType       = 'array';
    //protected $useSoftDeletes   = false;
    //protected $protectFields    = true;
    protected $allowedFields    = ['id_product','id_category'];
    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    public function rmCategoriesFromProduct($productId=null)
    {
       $this->where(['id_product'=>$productId])->delete();
    }
    public function insertCategoriesInProduct($categories=null,$productId=null)
    {      
        $values=[];
        foreach($categories as $category){
            $data=[
                'id_category'=>$category,
                'id_product'=>$productId
            ];
            array_push($values,$data);
        }
        return $this->ignore(true)->insertBatch($values);
    }

}
