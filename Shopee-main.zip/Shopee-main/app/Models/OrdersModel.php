<?php

namespace App\Models;

use CodeIgniter\Model;

class OrdersModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'Orders';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id','id_user','pago','updated_at','created_at'];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';


    public function getAllOrders($offset){
        $orders=$this->findAll(10,$offset);
        $total=$this->countAllResults();
        return [
            "orders"=>$orders,
            "total"=>$total
        ];
    }
    public function getOrder($orderId=null){
        return $this->find(['id'=>$orderId]);
    }
    
    public function deleteOrder($id=null){
        $removed=$this->delete(['id'=>$id]);
        if($removed) return true;
        else return false;
    }
    
    public function createOrder($data=null){
        $trataeddata=[
            'id_user'=>$data['user'],
            'pago'=>$data['pago'],
            'updated_at'=>$data['updated_at'],
            'created_at'=>$data['created_at']
        ];
        $orderId=$this->insert($trataeddata,true);
        if($orderId) return $orderId;
        else return false;
    }

    public function editOrder($id=null,$data=null)
    {
        $trdata=[
            'updated_at'=>$data['updated_at']
        ];
        $edited=$this->update($id,$trdata);
        if($edited) return true;
        else return false;
    }

    public function updatePaymentOrder($id=null)
    {
        $data=[
            'pago'=>1
        ];
        $this->update($id,$data);
    }

}
