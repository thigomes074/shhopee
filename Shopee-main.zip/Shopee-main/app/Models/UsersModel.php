<?php

namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name','email'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function all($search='',$offset=0){
        $users = $this->like('users.name',$search)->findAll(10,$offset);
        
        return $users;
    }

    public function create($data){
        $user = $this->insert($data);

        if ($user) {
            return true;
        } else {
            return false;
        }
    }

    public function findD($id){
        return $this->find($id);
    }

     public function updateE($id=null,$data=null){
        $user = $this->update($id,[
            'name'=>$data['name'],
            'email'=>$data['email'],
        ]);

        if($user) {
            return true;
        } else {
            return false;
        }
    }

    public function deleteE($id) {
        $user = $this->delete($id);

        if($user) {
            return true;
        } else {
            return false;
        }
    }

    public function getAllUsersWithOutLimit() {
        return $this->findAll();
    }

    public function getUser($id) {
        return $this->find($id);
    }
    
    public function links($search = '') {
        $total = $this->like('users.name',$search)->countAllResults();

        return $total;
    }
}
