<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductsModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'products';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name','qt','price','sinopse'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function all($searchTxt='',$offset=0,$filter=''){
        $products=$this->like('products.name',$searchTxt)->orderBy($filter,'DESC')->findAll(10,$offset);
        $total=$this->like('products.name',$searchTxt)->countAllResults();
        return [
            "products"=>$products,
            "total"=>$total
        ];
    }

    public function create($data){
        $id = $this->insert([
            'name'=>$data['name'],
            'qt'=>$data['qt'],
            'price'=>$data['price'],
            'sinopse'=>$data['sinopse']
        ],true);

        if($id) {
            return $id;
        } else {
            return false;
        }
    }

    public function getAllProductsWithOutLimit(){
        return $this->findAll();
    }
    public function getProduct($id=null){
        return $this->find($id);
    }

    public function updateE($id=null,$data=null){
        $product=$this->update($id,[
            'name'=>$data['name'],
            'qt'=>$data['qt'],
            'price'=>$data['price'],
            'sinopse'=>$data['sinopse'],
        ]);
        
        if($product) {
            return $id;
        } else {
            return false;
        }
    }

    public function updateProductsQt($id=null,$qt=null)
    {
        $trataeddata=[
            'qt'=>$qt,
        ];
        $edited=$this->update($id,$trataeddata);
        if($edited) return true;
        else return false;
    }
    
    public function deleteE($id){
        $this->delete($id);
        
        if($id) {
            return $id;
        } else {
            return false;
        }
    }
}
