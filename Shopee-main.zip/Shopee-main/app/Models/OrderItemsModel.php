<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderItemsModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'OrderItems';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id_order','id_product','qt','created_at','updated_at'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    public function getAllOrdersItems($orderId=null)
    {
        return $this->join('Products',"Products.id=OrderItems.id_product")->where(['OrderItems.id_order'=>$orderId])->select('Products.name,Products.price as price,Products.qt as productQt,OrderItems.id_product,OrderItems.qt')->findAll();
    }

    public function rmItemsFromOrder($orderId=null)
    {
        $removed=$this->where(['id_order'=>$orderId])->delete();
        if($removed) return true;
        else return false;
    }
    public function insertItemInOrder($items_orders=null,$orderId=null)
    {      

        $values=[];
        foreach($items_orders as $item_order){
            $data=[
                'qt'=>$item_order->qt,
                'id_order'=>$orderId,
                'id_product'=>$item_order->id_product,
            ];
            array_push($values,$data);
        }
        return $this->ignore(true)->insertBatch($values);
    }
    
}
