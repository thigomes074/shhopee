<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UsersModel;

class UsersController extends BaseController
{
    public function __construct() 
    {
        $this->model = new UsersModel();
    }

    public function index()
    {
        $search = "";
        $offset = 0;
        if ($this->request->getVar('search')) $search = $this->request->getVar('search');
        if ($this->request->getVar('offset')) $offset = $this->request->getVar('offset');

        $users = $this->model->all($search, $offset);
        $total = $this->model->links($search);

        return view('users/index',['users' => $users,'total' => $total]);
    }

    public function showStore()
    {
        return view('users/form', ['name' => '']);
    }

    public function store()
    {
        $user = $this->model->create([
            'name'=>$this->request->getVar('name'),
            'email'=>$this->request->getVar('email'),
        ]);

        return redirect()->to('/users');
    }

    public function showUpdate($id)
    {
        $user = $this->model->findD($id);
        return view('users/form',$user);
    }

    public function update($id)
    {
        $this->model->updateE($id,[
            'name'=>$this->request->getVar('name'),
            'email'=>$this->request->getVar('email')
        ]);
        
        return redirect()->to('/users');
    }

    public function delete($id)
    {
        $this->model->deleteE($id);

        return redirect()->to('/users');
    }
}