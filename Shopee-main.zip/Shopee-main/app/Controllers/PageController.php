<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PageController extends BaseController
{
    public function ShowOperationSelector()
    {
        return view('operationselector.php');
    }
}
