<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductsModel;
use App\Models\CategoriesModel;
use App\Models\ProductsCategoriesModel;

class ProductsController extends BaseController
{
    public function __construct()
    {
        $this->modelProducts = new ProductsModel();
        $this->modelCategories = new CategoriesModel();
    }

    public function index()
    {
        $filter=$this->request->getVar('filter') ? $this->request->getVar('filter') : "";
        $searchTxt=$this->request->getVar('searchTxt') ? $this->request->getVar('searchTxt') : "";
        $offset=$this->request->getVar('offset') ? $this->request->getVar('offset') : 0;
        $data=$this->modelProducts->all($searchTxt,$offset,$filter);

        for($c=0;$c<count($data['products']);$c++){

            $data['products'][$c]['categories'] = $this->modelCategories->getAllCategoriesFromProduct($data['products'][$c]['id']);
        }
        return view('products/index',$data);
    }

    public function showStore()
    {   
        $categories = $this->modelCategories->all();

        return view('products/form',['name'=>'', "product_categories"=>[], 'categories'=>$categories]);
    }
    
    public function store()
    {
        $categories = $this->request->getVar('categories');
        $categories = explode(',',$categories);
        
        $id = $this->modelProducts->create([
            'name'=>$this->request->getVar('name'),
            'qt'=>$this->request->getVar('qt'),
            'image'=>$this->request->getVar('image'),
            'price'=>$this->request->getVar('price'),
            'sinopse'=>$this->request->getVar('sinopse'),
        ]);

        if($id){
            $model=new ProductsCategoriesModel();
            $model->insertCategoriesInProduct($categories,$id);
            return redirect()->to('/products');
        }
    }

    public function showUpdate($id=null)
    {
        $categories = $this->modelCategories->getAllCategoriesWithOutLimit();
        $product = $this->modelProducts->getProduct($id);

        $product["categories"] = $categories;
        $product["product_categories"] = $this->modelCategories->getAllCategoriesFromProduct($id);

        return view('products/form',$product);
    }

    public function update($id = null)
    {
        $date = date('Y-m-d H:i:s');
        $categories=$this->request->getVar('categories');
        $categories=explode(',',$categories);
        $data=[
            'name'=>$this->request->getVar('name'),
            'qt'=>$this->request->getVar('qt'),
            'price'=>$this->request->getVar('price'),
            'sinopse'=>$this->request->getVar('sinopse'),
        ];
        $edited=$this->modelProducts->updateE($id,[
            'name'=>$this->request->getVar('name'),
            'qt'=>$this->request->getVar('qt'),
            'price'=>$this->request->getVar('price'),
            'sinopse'=>$this->request->getVar('sinopse'),
        ]);
        if($edited){
            $model=new ProductsCategoriesModel();
            //remove all that exists
            $model->rmCategoriesFromProduct($id);
            //and read after
            $model->insertCategoriesInProduct($categories,$id);
            return redirect()->to('/products');
        }
        else echo "Falhou";
    }

    public function delete($id = null)
    {
        $this->modelProducts->deleteE($id);
        
        return redirect()->to('/products');
    }
}
