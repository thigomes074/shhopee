<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\OrdersModel;
use App\Models\UsersModel;
use App\Models\ProductsModel;
use App\Models\OrderItemsModel;

class OrdersController extends BaseController
{
    public function getAllOrders()
    {
        $offset=$this->request->getVar('offset') ? $this->request->getVar('offset'):0;
        $model=new OrdersModel();
        $data=$model->getAllOrders($offset);
        $modelUsers=new UsersModel();
        $modelProducts=new OrderItemsModel();
        for($c=0;$c<count($data['orders']);$c++){
            $data['orders'][$c]['user']=$modelUsers->getUser($data['orders'][$c]['id_user']);
            $data['orders'][$c]['products']=$modelProducts->getAllOrdersItems($data['orders'][$c]['id']);
            
        }
        return view('orders/index',$data);

    }

    public function editOrder($id = null)
    {
        $item_orders=json_decode($this->request->getVar("products_orders"));
        $date = date('Y-m-d H:i:s');
        $data=[
            'id_user'=>$this->request->getVar('id_user'),
            'updated_at'=>$date
        ];
        $model=new OrdersModel();
        $edited=$model->editOrder($id,$data);
        if($edited){
            $model=new OrderItemsModel();
            $model->rmItemsFromOrder($id);
            $model->insertItemInOrder($item_orders->products,$id);
            $model=new ProductsModel();
            foreach ($item_orders->products as $product){
                $calc=$product->default_qt-$product->qt;
                $model->updateProductsQt($product->id_product,$calc);
            }
            return redirect()->to('/orders');
        }
        else echo "Falhou";
    }

    public function deleteOrder($id = null)
    {
        $model=new OrderItemsModel();
        $deleteItems=$model->rmItemsFromOrder($id);
        if($deleteItems){
            $model=new OrdersModel();
            $model->deleteOrder($id);
            return redirect()->to('/orders');
        }
        else echo "falhou";
    }

    public function createOrder()
    {
        
        $item_orders=json_decode($this->request->getVar("products_orders"));
        $date=date('Y-m-d H:i:s');
        $data=[
            'user'=>$this->request->getVar('user'),
            'created_at'=>$date,
            'updated_at'=>$date,
            'pago'=>0
        ];
        $model=new OrdersModel();
        $orderId=$model->createOrder($data);
        if($orderId){
            $model=new OrderItemsModel();
            $model->insertItemInOrder($item_orders->products,$orderId);

            $model=new ProductsModel();
            //update cada produto qt
            foreach ($item_orders->products as $product){
                $calc=$product->default_qt-$product->qt;
                $model->updateProductsQt($product->id_product,$calc);
            }
            return redirect()->to('/orders');
        }
        else echo "Erro";
        
    }

    public function payOrder($id)
    {
        $model=new OrdersModel();
        $model->updatePaymentOrder($id);
        return redirect()->to('/orders');
    }

    public function showEditOrderForm($id=null)
    {
        $model=new OrdersModel();
        $modelItems=new OrderItemsModel();
        $data=$model->getOrder($id)[0];
        $data['items']=$modelItems->getAllOrdersItems($id);
        $modelProduct=new ProductsModel();
        $products=$modelProduct->getAllProductsWithOutLimit();
        $modelUser=new UsersModel();
        $users=$modelUser->getAllUsersWithOutLimit();
        $data["users"]=$users;
        $data["products"]=$products;
        if($data['pago']==0) return view('orders/form',$data);
    
    }

    public function showCreateOrderForm()
    {   
        $modelProduct=new ProductsModel();
        $products=$modelProduct->getAllProductsWithOutLimit();
        $modelUser=new UsersModel();
        $users=$modelUser->getAllUsersWithOutLimit();
        return view('orders/form',['id'=>'','id_user'=>'','pago'=>'','created_at'=>'','updated_at'=>'','items'=>[],'products'=>$products,'users'=>$users]);
    }
}
