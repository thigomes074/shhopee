<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CategoriesModel;
date_default_timezone_set('America/Sao_Paulo');

class CategoriesController extends BaseController
{
    public function __construct()
    {
        $this->model = new CategoriesModel();
    }

    public function index()
    {
        $search = $this->request->getVar('search') ? $this->request->getVar('search') : '';
        $offset = $this->request->getVar('offset') ? $this->request->getVar('offset') : 0;

        $categories = $this->model->all($search, $offset);
        $total = $this->model->links($search);

        return view('categories/index',['categories' => $categories,'total' => $total]);
    }

    public function showStore()
    {
        return view('categories/form',['name'=>'']);
    }

    public function store()
    {
        $this->model->create([
            'name'=>$this->request->getVar('name'),
        ]);

        return redirect()->to('/categories');
    }

    public function showUpdate($id)
    {
        $category = $this->model->findD($id);
        return view('categories/form',$category);
    }

    public function update($id)
    {
        $edited=$this->model->updateE($id,['name'=>$this->request->getVar('name')]);
        
        return redirect()->to('/categories');
    }

    public function delete($id)
    {
        $this->model->deleteE($id);

        return redirect()->to('/categories');
    }
}
